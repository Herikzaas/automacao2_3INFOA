concen = float(input('Digite a concentracao'))
peso = float(input('Digite o peso'))
dose = float(input('Digite a dose recomendada'))

result = (peso*dose)/concen

print(f'resultado = {result*20}')