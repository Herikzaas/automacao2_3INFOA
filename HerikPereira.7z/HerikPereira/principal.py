from funcao import entrada

result = entrada('Digite um valor')
print(result)
