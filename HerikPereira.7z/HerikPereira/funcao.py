def entrada (x) :
    print(x)
    return input()