num = int(input('Digite um numero'))

if num < 0 :
    print('Retroceder')
elif num == 0 :
    print('Pare')
elif num > 0 :
    print('Avancar')